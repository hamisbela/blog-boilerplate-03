# How To See Resolved & Unresolved Comments in A Canva Design? [in 2025]

In this article, we will guide you through the steps to see resolved and unresolved comments in a Canva design, making your collaboration process easier and more efficient. If you want to dive deeper, check out our tutorial video here: https://www.youtube.com/watch?v=S8ngUo6_iTY.

## What Are Comments in Canva Designs?

**Comments in Canva** are an essential feature that allows users to provide feedback, suggestions, or requests regarding a specific design element. 

Whether you're working on a team project or seeking feedback from clients, comments help keep everyone on the same page. 

Some benefits of comments in Canva include:

- **Real-time feedback:** Users can comment directly on the design elements, making it easier to discuss changes.
- **Clarity:** Clear communication reduces misunderstandings and ensures everyone knows what revisions are needed.
- **Organization:** Comments help you keep track of your design progress and any modifications requested.

## How Do You Access All Comments in Canva?

Accessing all comments in your Canva design is simple and straightforward. 

Follow these steps:

1. **Open your design in Canva:** Log into your Canva account and select the desired design.
2. **Click on 'File':** You’ll find this option located in the top-left corner of the screen.
3. **Select 'View All Comments':** This option will allow you to see a dropdown list showing all comments associated with your design.

Once you click on 'View All Comments,' a new panel will appear on the side of the screen, displaying all feedback related to your design.

## How Are Comments Segmented into Resolved and Unresolved?

In Canva, comments are categorized into two distinct sections: **resolved** and **unresolved** comments. 

This segmentation helps users prioritize which comments still need attention and which have already been addressed. 

- **Unresolved Comments:** These are comments that require further action or clarification. 
- **Resolved Comments:** These are comments that have been addressed and no longer require any follow-up.

To view these segments:

- After clicking on 'View All Comments,' you'll see two separate tabs—one for unresolved and one for resolved comments.

- This organization helps streamline the review process and ensures that nothing falls through the cracks.

## What Are Your Options for Managing Comments in Canva?

Once you’ve accessed all comments in your design, Canva provides various options to manage these comments effectively. 

Here’s how to handle your comments:

1. **Deleting Comments:** If a comment is no longer relevant, simply click on the three dots next to the comment and select 'Delete.' 
2. **Restoring Comments:** If a resolved comment requires further discussion, you can restore it back to the unresolved section by clicking on the three dots and selecting 'Restore.'
3. **Responding to Comments:** You can reply to comments directly, providing clarity or requesting additional information.
4. **Filtering Comments:** Use the tabs for resolved and unresolved comments to focus on what you need to address immediately.

These options empower you to maintain control over the feedback process, ensuring that all suggestions are adequately addressed.

## Where Can You Find Additional Canva Resources and Tutorials?

If you’re looking to enhance your Canva skills even further, there are a plethora of resources available online. 

Here are some recommended places to explore:

- **Canva’s Official Help Center:** This is a treasure trove of information, offering articles and videos on various features and functionalities of Canva.

- **YouTube Tutorials:** Channels dedicated to design tools offer a myriad of Canva tutorials, including expert tips and tricks.

- **Online Communities:** Platforms like Reddit and Facebook host groups where Canva users exchange ideas, tips, and tutorials.

- **Canva Blog:** The Canva blog regularly posts articles on design trends, tips, and new features introduced in Canva.

- **Canva Pro Resources:** If you are using Canva Pro, a variety of exclusive resources, templates, and tools are available to enhance your design experience.

Utilizing these resources can help you get the most out of Canva, improving your design proficiency over time.

## Conclusion

In 2025, understanding how to see both resolved and unresolved comments in your Canva designs is crucial for anyone looking to enhance their collaboration and feedback processes. 

Through the simple three-step process of accessing comments and managing them effectively, you can ensure that your designs evolve and improve based on constructive feedback.

Remember, comments in Canva are not just notes—they are dynamic elements that drive your design forward.

For more tips and in-depth tutorials, don’t forget to check out our YouTube channel, where we regularly share updates and insights into Canva’s myriad features. 

By leveraging these tools and resources, you can elevate your design game while staying organized and efficient. Happy designing!