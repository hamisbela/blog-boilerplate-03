# How To Uncapitalize Text in Canva? [in 2025]

In this article, we'll explore how to uncapitalize text in Canva, a feature that can enhance the readability and style of your design.

For more visuals, you can check out our video tutorial here: https://www.youtube.com/watch?v=nBDz3FecRas.

## What is the Uppercase Effect in Canva?

The **uppercase effect** is a formatting option within Canva that transforms all the letters in a selected text element to uppercase. This effect can be useful when you want to create a bold impression or maintain consistency in certain design elements. However, there may be times when you want to revert your text back to its original format, which leads us to the next section.

## How to Identify the Text Element to Uncapitalize?

Before you can **uncapitalize text in Canva**, it’s essential to identify the correct text element. Here are the steps:

1. **Locate the Text Box**: Click on the canvas area where your design is located.

2. **Select the Text**: Hover over the text you want to edit and click on it to ensure it is selected.

3. **Check for the Uppercase Effect**: If the text appears fully capitalized, it likely has the uppercase effect applied.

## Where Can You Find the Uppercase Icon in Canva?

To uncapitalize text in Canva, you'll need to find the **uppercase icon**. Here’s how:

1. **Text Editing Toolbar**: After selecting your text, navigate to the top row of your Canva interface.

2. **Look for the Uppercase Icon**: This icon usually appears as "TT" or "A" in uppercase letters. It indicates the current text formatting.

## What are the Steps to Uncapitalize Text in Canva?

Once you've identified the text element and located the uppercase icon, uncapitalizing your text is simple. Follow these steps:

1. **Select the Text Element**: Click on the text you wish to change.

2. **Access the Editing Toolbar**: Look at the top of the Canva interface where the editing options are displayed.

3. **Click on the Uppercase Icon**: If you see that the uppercase effect is active, click on the **uppercase icon** (the one that looks like "TT"). 

4. **View the Changes**: Instantly, you’ll notice that your text has transformed from uppercase to lowercase.

This process ensures that you can easily manage the text formatting in your design.

## How to Recapitalize Text in Canva if Needed?

If for any reason you need to **recapitalize your text**, the process is just as straightforward:

1. **Select the Text Again**: Click on the text that you previously uncapitalized.

2. **Return to the Uppercase Icon**: Head back to the editing toolbar.

3. **Re-click the Uppercase Icon**: Click on the uppercase icon once more to apply the uppercase effect.

4. **Check the Result**: Your text should now revert back to fully capitalized.

By understanding these steps, you can easily toggle between uppercase and lowercase as needed.

## Conclusion

In summary, uncapitalizing text in Canva is a quick and efficient process that can significantly affect your design’s overall look. 

Utilizing the uppercase effect can enhance your text; however, being able to toggle this effect on and off allows for greater flexibility.

Now you have comprehensive instructions on how to uncapitalize text in Canva, along with the ability to capitalize again if needed. 

Happy designing!