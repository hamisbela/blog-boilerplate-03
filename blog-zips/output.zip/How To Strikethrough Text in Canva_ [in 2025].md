# How To Strikethrough Text in Canva? [in 2025]

In this guide, we will explore how to strikethrough text in Canva and enhance your design projects.

If you're looking for a quick tutorial, you can also check out our video: https://www.youtube.com/watch?v=1WIoRwN1bzo.

## What Is the Strikethrough Text Feature in Canva?

The **strikethrough text feature** in Canva is a valuable tool that allows you to add a line through your text. This feature is particularly useful in various design scenarios:

- **To indicate completed tasks** in a list.
- **To highlight revisions** or edits in written materials.
- **To display discounted prices** in promotional content.

By utilizing the strikethrough effect, you can communicate ideas more effectively while maintaining a visually appealing design.

## How Do You Add Strikethrough to Text in Canva?

Adding strikethrough to your text in Canva is a straightforward process. Follow these simple steps:

1. **Open Canva:** Launch the Canva application or website.

2. **Select Your Text:** Click on the text box that contains the text you want to strike through.

3. **Access the Top Menu:** Once the text box is selected, a **top menu bar** appears.

4. **Locate Strikethrough:** In the menu, look for the **strikethrough icon**, usually represented by a line crossing through the text. 

5. **Apply the Effect:** Click on the strikethrough option.

Now, the strikethrough effect has been applied to your selected text! 

**Note:** Not all fonts in Canva support the strikethrough feature. If the strikethrough option is grayed out or not appearing, the issue may be related to the font you are using.

## Which Fonts Support Strikethrough in Canva?

While most fonts in Canva work seamlessly with the strikethrough feature, some do not support this effect. 

### Fonts That Typically Support Strikethrough:
- **Sans Serif Fonts:** Arial, Montserrat, Roboto.
- **Serif Fonts:** Times New Roman, Georgia.
- **Display Fonts:** Raleway, Lora.

If your selected font does not allow for strikethrough, consider switching to one of the aforementioned fonts to utilize this feature effectively.

## What Alternative Method Exists for Strikethrough Text?

If you encounter fonts that do not support strikethrough or simply prefer a different approach, there’s an alternative method:

1. **Using a Line Element:**
- **Insert a Line:** Go to the elements tab and add a line to your design.
- **Position the Line:** Resize and move the line over the text you want to strike through.
- **Adjust the Line Style:** You can change the thickness and color of the line to match your design needs.

This method gives you more artistic freedom and allows you to customize the strikethrough effect according to your design style.

## How Can You Access More Canva Resources and Tutorials?

Canva is an extremely versatile design tool, and there are countless resources available to enhance your skills. To access more tutorials and resources:

1. **YouTube Channel:** Visit our YouTube channel, which hosts over a thousand free tutorials on various Canva features.

2. **Free Resources:** Download our **Make Money with Canva checklist**, where we reveal numerous ways to monetize your design skills.

3. **Join Canva Pro:** Consider signing up for Canva Pro, which offers a free 14-day trial, allowing you to explore advanced features and templates.

4. **Community Forums:** Engage in Canva community forums where experienced designers share tips, tricks, and assistance.

By actively utilizing these resources, you can exponentially improve your Canva skills and expand your design capabilities.

## Conclusion

In summary, learning how to strikethrough text in Canva can elevate your design projects significantly. 

Whether you're using it for completing tasks, editing content, or creating promotional materials, the strikethrough text feature can effectively enhance your communication.

If you're encountering issues with certain fonts, remember that you can also use the line element as an alternative method. 

Don't forget to explore additional resources to sharpen your skills and leverage Canva to its fullest potential. 

Looking to boost your design game? Dive into the world of Canva today!