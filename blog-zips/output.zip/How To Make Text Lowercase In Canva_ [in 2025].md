# How To Make Text Lowercase In Canva? [in 2025]

In this article, we’ll explore how to make text lowercase in Canva and discuss its benefits, additional text transformations, and resources for learning more about Canva.

For a quick visual guide, you can watch our tutorial here: https://www.youtube.com/watch?v=fOSnRJN8Rho

## Why Use Lowercase Text in Designs?

Using lowercase text in your designs can enhance aesthetics and improve readability. Here are several reasons why you might consider incorporating lowercase text:

- **Modern Aesthetic**: Many brands are moving towards a more relaxed, casual look. Lowercase text often gives off a laid-back vibe.

- **Readability**: Lowercase letters can be easier to read, especially in longer texts, as they offer clearer word shapes and less visual clutter.

- **Emotional Appeal**: Lowercase text can convey friendliness and approachability, making your designs more relatable to your audience.

- **Versatility**: Depending on your design theme, lowercase text can fit a range of styles, from whimsical to professional.

Understanding the impact of your text style is crucial, and using lowercase when appropriate can help align your design with your intended message.

## What Are the Steps to Change Text to Lowercase?

Making text lowercase in Canva is a straightforward process. Here's how you can do it:

1. **Select the Text Box**: Click on the text box containing the words you want to change. If you have multiple text layers, you’ll need to select each one individually.

2. **Locate the Uppercase Icon**: Look at the top bar of the Canva interface. 

3. **Toggle the Icon**: You will see an icon that indicates whether your text is currently in uppercase or not. If it’s highlighted, it means your text is set to uppercase. 

4. **Deselect the Uppercase Option**: Clicking on this icon will toggle off the uppercase setting, transforming your text into lowercase.

5. **Check Your Work**: After making your adjustments, review your design to ensure that your text looks just the way you want it.

By following these simple steps, you can easily change uppercase text to lowercase in Canva without needing to retype your content.

## Where to Find the Uppercase Icon in Canva?

The uppercase icon is located at the top of the Canva editor toolbar. 

- Once you’ve clicked on the text layer, look towards the right side of the toolbar.

- The icon may appear as a capital "A" with a line underneath or as a stylized letter representing cases.

- If the icon is highlighted, that indicates your selected text is currently uppercase. 

Simply clicking on it will allow you to switch back to lowercase effortlessly.

## What Other Text Transformations Can You Make in Canva?

Canva offers a variety of text transformation options beyond just changing to lowercase. Here are some additional features you can explore:

- **Uppercase**: Use this to convert your text to all capital letters, great for emphasis.

- **Title Case**: Capitalize the first letter of each word; this is useful for headings and titles.

- **Strikethrough**: Apply a line through your text, useful for indicating deleted or outdated information.

- **Letter Spacing**: This adjusts the space between letters to help your text stand out.

- **Line Height**: Modify the distance between lines of text, ensuring your typography is legible and visually appealing.

- **Text Color**: Change the color of your text to match your design’s color palette.

- **Font Style**: Experiment with different fonts to achieve the desired look for your design.

Utilizing these transformations can elevate your design by making your text both functional and visually appealing.

## How Can You Access Free Canva Resources and Tutorials?

Canva is a powerful design tool that offers various resources to help you maximize your skills. Here’s how you can access free resources and tutorials:

- **Canva Help Center**: Explore the Help Center for articles and tutorials that cover a wide range of topics, perfect for beginners and experienced users alike.

- **YouTube Tutorials**: Follow the Canva YouTube channel and check out numerous step-by-step video guides. You can find playlists dedicated to specific features or design tactics.

- **Design Courses**: Various platforms, including Canva’s own design school, offer free courses tailored to different user levels, from rookies to experienced designers.

- **Online Communities**: Join online forums and social media groups focused on Canva. Engaging with others can provide tips and tricks not covered in official resources.

- **Blogs and Articles**: Many design blogs feature articles detailing how to use Canva effectively, giving you insights into the latest features and design trends.

By leveraging these resources, you can become proficient in using Canva and unlock your design potential.

## Final Thoughts

Knowing how to make text lowercase in Canva is just one of the many skills you can learn to enhance your designs. 

Lowercase text can modernize your work, improve readability, and convey a friendly atmosphere to your audience. 

With the ability to transform text seamlessly and access numerous free resources, you can continually evolve your skills and creativity. 

If you are looking for additional ways to utilize Canva, including how to earn money through design, don’t forget to check out our free checklist linked in our video description.

Get creative, and happy designing!