# How To Add Comments In Canva? [in 2025]

In this article, you will learn how to efficiently add comments in Canva, enhancing collaboration and communication within your design projects.

For a detailed video tutorial, check out this link: https://www.youtube.com/watch?v=6nXhT-qWEPo

---

## 1. How To Add Comments In Canva?

Adding comments in Canva not only streamlines your design process but also fosters teamwork, allowing you to gather feedback and make adjustments based on collaborative input.

Whether you are working on a presentation, social media graphic, or any design project, **commenting** helps clarify ideas and notes effectively.

Here's a step-by-step guide on how to add comments in Canva:

1. **Open Your Design**: Start by launching your Canva design.

2. **Select the Page or Element**: Decide whether you want to comment on a specific page or an element within the design.

3. **Access the Comment Feature**: Use the comment feature to leave your notes or feedback.

With these basic instructions, you can confidently add comments throughout your Canva projects.

---

## 2. What Are the Two Main Ways to Add Comments in Canva?

There are **two primary methods** to add comments in Canva:

### A. Commenting on a Page

- Click the page where you want to leave a comment.
- Locate the **Add a comment icon** and click it.
- Input your comment in the dialogue box.
- Use the "@" symbol to mention team members, ensuring they receive a notification.

### B. Commenting on Specific Elements

- Click on the design element you want to comment on (e.g., a text box, image, or shape).
- Find the **three dots** on the top right of the selection.
- Click on it and select **Comment**.
- Type your comment in the dialogue box, then click the **comment button** to submit.

These two methods can vastly improve communication while working on Canva, making it easier to receive and implement feedback.

---

## 3. How to Add Comments to a Specific Page in Canva?

To add comments to a specific page in Canva, follow these simple steps:

1. **Navigate to Your Design**: Open your Canva project.

2. **Select the Target Page**: Click on the page you wish to comment on.

3. **Use the Comment Feature**: 

- Click the **Add a comment icon**.
- A dialogue box will appear.
- Type your thoughts or feedback.

4. **Tag Team Members if Needed**: If you want particular team members to pay attention to your comment, **mention them** by using the "@" symbol followed by their name.

5. **Submit Your Comment**: Click on the **comment button** to post it.

This process ensures that your feedback is directed to a specific page, enabling precise discussions about design elements.

---

## 4. How to Comment on Specific Elements in Canva Designs?

Commenting on specific elements within your Canva designs helps your team understand what needs to be addressed:

1. **Open Your Canva Design**: Start by accessing the design you are working on.

2. **Select the Element**: Click on the element (text, image, etc.) you wish to comment on.

3. **Access Comment Options**:

- Find the **three dots** in the top-right corner of the selected element.
- Click on them and select **Comment** from the dropdown menu.

4. **Type Your Comment**: In the comment box that opens, share your feedback or suggestion.

5. **Tag Team Members**: If relevant, use the "@" symbol to mention anyone who needs to look at your comment.

6. **Submit the Comment**: Click on the **comment button** to finalize.

By following these steps, your comments will be attached directly to specific design elements, making feedback clear and actionable.

---

## 5. What Happens After Adding Comments in Canva?

After adding comments in Canva, the following occurs:

- **Visible Feedback**: Your comments become visible to anyone with access to the design, facilitating open discussion.

- **Notifications**: Team members tagged in comments receive notifications, prompting them to review your feedback.

- **Resolve Comments**: Once a comment has been addressed, the team member can click the **checkmark** to mark it as resolved, helping keep track of which points need attention.

- **Ongoing Collaboration**: The commenting feature allows for ongoing dialogue, enabling iterative improvements to your designs.

These functionalities ensure your project stays organized and that team communication is seamless.

---

## 6. Where to Find More Resources for Learning Canva?

To enhance your skills and knowledge of Canva, several resources are available:

1. **Official Canva Resources**: Canva’s help center provides countless tutorials, articles, and guides for various tools and features.

2. **YouTube Tutorials**: Search for Canva tutorials on YouTube, where content creators share useful tips and tricks.

3. **Online Courses**: Platforms like Udemy and Skillshare offer in-depth courses on Canva, covering everything from basics to advanced strategies.

4. **Community Forums**: Join Canva user communities on social media platforms where users share experiences, tips, and guidance.

5. **Blogs and Articles**: Look for blogs that focus on design tools—these often cover the latest updates, tips, and industry news about Canva.

Utilizing these resources will ensure that you stay up-to-date with all functionalities of Canva and improve your design skills.

---

By following the steps outlined above, you'll not only know how to add comments in Canva but also enhance collaboration with your team for more efficient design processes. Happy designing!