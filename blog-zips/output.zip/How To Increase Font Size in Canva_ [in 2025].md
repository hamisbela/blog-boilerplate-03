# How To Increase Font Size in Canva? [in 2025]

In this article, we'll guide you on how to effectively increase font size in Canva to elevate your design projects. For a visual tutorial, check out the following video: https://www.youtube.com/watch?v=HlgQJKlfZVQ.

## What Are the Basic Steps to Adjust Font Size?

Increasing font size in Canva is straightforward.

**Follow these basic steps to adjust font size:**

1. **Open Your Canva Design**: Start by launching the Canva platform and opening the design where you wish to adjust the font size.

2. **Select the Text**: Click on the text box or text element that you want to modify.

3. **Locate the Top Bar**: Once you select the text, you will notice a top bar with various editing options.

By completing these steps, you're ready to increase the font size in your design!

## Which Tools in Canva Help You Change Font Size?

Canva provides several tools that facilitate the process of changing font size. Here are the primary options you can use:

- **Font Size Dropdown**: This is located in the top bar. You can quickly select from preset sizes.

- **Plus Icon**: A convenient feature that allows you to incrementally increase font size.

- **Manual Entry Field**: This gives you the ability to type in a specific font size.

- **Text Resize Handles**: This is an option where dragging can also adjust the size of your text.

Utilizing these tools will allow you to seamlessly modify your font size in Canva.

## How to Use the Plus Icon for Font Size Adjustment?

The plus icon is one of the easiest ways to increase font size in Canva:

1. **Select Your Text**: Click on the text element you would like to modify.

2. **Find the Font Size Option**: Look for the font size displayed in the top bar.

3. **Click on the Plus Icon**: Each time you click this icon, the font size will increase.

The benefit of using the plus icon is that you can make gradual adjustments, allowing for precise control over how large you want your text to appear.

## Can You Manually Enter Font Sizes in Canva?

Yes, Canva allows you to manually enter font sizes, which is particularly useful if you have a specific measurement in mind.

**To manually enter the font size:**

1. **Select Your Text**: As with other methods, start by clicking the text you want to edit.

2. **Locate the Font Size Field**: In the top bar, find the font size option.

3. **Type Your Desired Size**: Click on the font size number and manually input your desired size.

4. **Press Enter**: This will apply the new font size immediately.

Manually entering font sizes is ideal for achieving unique styling or aligning with brand guidelines.

## What Other Tips and Resources Are Available for Canva Users?

To make the most of Canva, here are some additional tips and resources designed to help you increase font size and enhance your overall experience:

- **Experiment with Font Pairing**: Use contrasting font sizes to create visual interest in your designs.

- **Utilize Canva Resources**: Explore Canva’s vast library of templates and design elements that can complement your text.

- **Join Canva Communities**: Engage with other Canva users on social media or forums to learn new tips and tricks.

- **Check Canva’s Help Center**: For more in-depth questions or issues, the Help Center offers tutorials and guides specifically tailored to user queries.

- **Follow Design Tutorials**: Websites, blogs, and YouTube channels often provide additional resources that can deepen your understanding of Canva's features.

By implementing these tips, you'll not only improve your skills in increasing font size in Canva but also enhance your overall design capabilities.

## Conclusion

Increasing font size in Canva doesn’t have to be a complicated task. By following the basic steps outlined above and utilizing the different tools available within Canva, you can easily adjust font sizes to suit your design needs.

Whether you prefer using the plus icon, manually entering sizes, or utilizing the text resize handles, Canva gives you the flexibility to create visually appealing designs that capture your audience's attention. 

As you explore more features within Canva and apply the suggested tips, you will enhance your skills and make your designs stand out in 2025 and beyond. Happy designing!