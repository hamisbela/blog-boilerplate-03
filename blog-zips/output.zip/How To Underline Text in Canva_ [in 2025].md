# How To Underline Text in Canva? [in 2025]

In this article, we aim to guide you step-by-step on how to underline text in Canva effectively.

For a visual walkthrough, check out our YouTube tutorial here: https://www.youtube.com/watch?v=oc2PQYqU0Ms.

## What Are the Steps to Underline Text in Canva?

Underlining text in Canva is a breeze! Here’s how to do it:

1. **Select the Text Element** 
Start by clicking on the text box that contains the text you want to underline.

2. **Access the Text Editing Toolbar** 
Once your text element is selected, look at the top toolbar. This is where you'll find various text editing options such as changing font color, size, and style.

3. **Click on the Underline Icon** 
Among these options, you’ll find an icon that looks like a line beneath a letter "U." 
Click this icon to underline your selected text.

4. **Confirm the Change** 
After clicking the underline icon, you should see your text underlined immediately. 

By following these simple steps, you can underline text in Canva with minimal effort. 

## What Keyboard Shortcuts Can You Use for Underlining?

For those who prefer keyboard shortcuts, Canva has you covered. Here are the shortcuts to underline text quickly:

- **Windows**: Press **CTRL + U** 
- **Mac**: Press **CMD + U**

Simply select the text you want to underline and use the appropriate keyboard shortcut. This action will toggle the underline on or off, giving you the flexibility to make changes swiftly.

## Why Might Some Fonts Not Support Underlining?

While underlining text in Canva is straightforward, you might encounter situations where the underline option is grayed out or unavailable. 

**Reasons for this include:**

- **Font Compatibility**: Not all fonts support underlining. If you're using a unique or decorative font, it may not have the underline functionality.

- **Design Limitations**: Certain designs and styles may prioritize aesthetics over functionality, leading to the absence of an underline feature for specific fonts.

When this happens, you can simply switch to a different font or explore alternative methods to underline your text.

## How to Manually Create Underlines with Shapes?

If you find yourself using a font that doesn’t support underlining, don’t worry! You can manually underline text in Canva using shapes. Here’s how:

1. **Select the Line Tool** 
On the left side of the Canva interface, navigate to the "Elements" tab and select the "Lines" option.

2. **Draw the Line** 
Click and drag to draw a line beneath your text. You can adjust the thickness and length of the line as necessary.

3. **Position the Line** 
Move the line to align it perfectly with your text. Use the alignment tools in Canva to ensure it’s centered below the text.

4. **Customize the Line** 
Feel free to change the line’s color and thickness to match your design aesthetics.

By using this technique, you can effectively create a manual underline that aligns with any font you choose, particularly those lacking underline support.

## Where to Find More Canva Resources and Tutorials?

Canva offers a wealth of resources for users eager to learn more about the platform. Here’s where you can find additional tutorials and tips:

1. **Canva Design School** 
Access the Canva Design School for a variety of free courses covering everything from basic to advanced design techniques.

2. **YouTube Channel** 
Our own YouTube channel is packed with over a thousand tutorials tailored to help you harness the full potential of Canva. You’ll find everything from creating social media graphics to advanced editing techniques.

3. **Blogs and Articles** 
Check out various design blogs focused on Canva. These resources often share tips, design inspiration, and updates on new features.

4. **Canva Community** 
Join the Canva community on social media and forums. It’s a great place to ask questions, seek advice, and share your creations!

By exploring these resources, you can enhance your Canva skills and create stunning designs that stand out.

---

In conclusion, underlining text in Canva is easily achievable through a few simple steps and keyboard shortcuts, even if some fonts present limitations. With this knowledge, you can effectively emphasize your text, whether using the built-in underline feature or manually adding lines. Don’t forget to explore the wealth of resources available to further your design skills. Happy designing!